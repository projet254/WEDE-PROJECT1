// ======================================================
// Session 1: JavaScript basics for Brew Haven Coffee Shop
// ======================================================

console.log("Brew Haven Coffee Shop JavaScript is connected!");

const specialMessage = document.querySelector("#special-message");
const specialButton = document.querySelector("#special-button");
const specialImage = document.querySelector("#special-image");

if (specialMessage && specialButton && specialImage) {

    specialButton.addEventListener("click", function () {

        specialMessage.textContent =
            "Today's special: freshly brewed coffee and delicious pastries. Visit us to see today's flavours!";

        specialImage.hidden = false;

        specialButton.textContent = "Special viewed";

        specialButton.disabled = true;

    });
}


// ======================================================
// Session 2: Search, lightbox, and accordion
// ======================================================


// FEATURE 1: PRODUCT SEARCH (products.html ONLY)

const productSearch = document.querySelector("#product-search");
const searchMessage = document.querySelector("#search-message");
const productCards = document.querySelectorAll(".services-card");

if (productSearch && searchMessage && productCards.length > 0) {

    productSearch.addEventListener("input", function () {

        const searchText = productSearch.value.toLowerCase().trim();

        let numberOfMatches = 0;

        productCards.forEach(function (card) {

            const cardText = card.textContent.toLowerCase();

            const cardMatches = cardText.includes(searchText);

            card.hidden = !cardMatches;

            if (cardMatches) {
                numberOfMatches++;
            }

        });

        searchMessage.textContent =
            numberOfMatches === 0
                ? "No products match your search."
                : numberOfMatches + " product(s) found.";

    });

}


// FEATURE 2: IMAGE LIGHTBOX

const imageLightbox = document.querySelector("#image-lightbox");
const enlargedImage = document.querySelector("#lightbox-image");
const closeLightboxButton = document.querySelector("#close-lightbox");

const productImages = document.querySelectorAll(".lightbox-image");

if (imageLightbox && enlargedImage && closeLightboxButton) {

    productImages.forEach(function (productImage) {

        productImage.addEventListener("click", function () {

            enlargedImage.src = productImage.src;

            enlargedImage.alt = productImage.alt;

            imageLightbox.showModal();

        });

    });

    // CLOSE THE LIGHTBOX

    closeLightboxButton.addEventListener("click", function () {

        imageLightbox.close();

    });

    // CLEAR IMAGE WHEN CLOSED

    imageLightbox.addEventListener("close", function () {

        enlargedImage.src = "";

    });

}


// FEATURE 3: ACCORDION

const accordionButtons = document.querySelectorAll(".accordion-button");

accordionButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        const details = button.nextElementSibling;

        const detailsAreHidden = details.hidden;

        details.hidden = !detailsAreHidden;

        button.setAttribute(
            "aria-expanded",
            String(detailsAreHidden)
        );

        button.textContent = detailsAreHidden
            ? "Hide cake details"
            : "Show cake details";

    });

});


// ======================================================
// END OF BREW HAVEN JAVASCRIPT
// ======================================================